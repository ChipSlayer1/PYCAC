#import necessary files
import json
import datetime
import add_people
import remove_people
import operator

#remove outdated people
remove_people.remove_outdated()

#read people.txt to list
f = open("stored_info/people.txt", "r")
text = f.read()
f.close()
people_json = text.split("\n-_-\n")

# keep track of people and cacs
people = []
cacs = []

# convert from javascript object to dict
try:
    for i in people_json:
        people.append(json.loads(i))
except Exception as e:
    print()

#update status file for every person
def updateStatus():
    try:

        #create stats list
        stats = []

        if len(people) > 0:
            people.sort(key=operator.itemgetter("last name")) 

        # people in mdr
        for i in people:
            if i["in_mdr"] == True:
                stats.append("{}, {} ===> IN (mdr bldg 627a) ===> {}".format(i["last name"], i["first name"], i["squadron"]))
            else:
                # people out of mdr
                stats.append("{}, {} ===> OUT at {} ===> {}".format(i["last name"], i["first name"], i["location"], i["squadron"]))
        
        # clear stats file and write header
        f = open("stored_info/people_status.txt", "w")
        f.write("________NAME________LOCATION_____________SQDR\n")
        f.close()

        # write stats to file
        for i in stats:
            f = open("stored_info/people_status.txt", "a")
            f.write(i + "\n")
            f.close()

    # in case of exception
    except Exception as e:
        print("Hmm. Something went wrong.")

# initial status
updateStatus()

# get all cac numbers in list
for i in people:
    cacs.append(i["CAC"])

# loop
while True:

    # request instructions
    action = input("Are you signing in or out?\n(type 'admin' for admin options)\n")
    action = action.lower()

    # signing in
    if action == "in":
        sign_in = False

        # get scanned cac num
        cac_in = input("scan your cac\n")

        # search through all people
        for i in people:

            # get person by cac
            if i["CAC"] == cac_in:

                # set location to mdr
                i["location"] = "mdr"
                i["in_mdr"] = True

                # log timestamp
                curr_time = datetime.datetime.now()

                # update log file
                f = open("stored_info/logs.txt", "a")
                f.write("{}, {} signed in to the Hangar at {}.\n".format(i["last name"], i["first name"], curr_time))
                f.close()
                print("Ok, you're signed in.")
                sign_in = True
        
        if sign_in == False:
            add_people.unknown_cac(cac_in)
            # read updated people.txt file
            f = open("stored_info/people.txt", "r")
            text = f.read()
            f.close()
            people_json = text.split("\n-_-\n")
            people = []

            # add people to list
            try:
                for i in people_json:
                    people.append(json.loads(i))
            except Exception as e:
                print()
            cacs.append(cac_in)

    # signing out            
    elif action == "out":

        # request cac to be scanned
        cac_out = input("scan your cac\n")

        # loop through all people
        for i in people:

            # if person found based on cac
            if i["CAC"] == cac_out:

                # request location info and update accordingly
                reason = input("What kind of sign out is this? (Details\nAppointment\nOut Processing\nOther)\n")
                reason = reason.lower()
                i["location"] = input("Where are you going?\n")
                i["location"] = i["location"].lower()
                i["in_mdr"] = False

                #update timestamp
                curr_time = datetime.datetime.now()
                f = open("stored_info/logs.txt", "a")
                f.write("{}, {} left the Hangar to go to {} for {} at {}.\n".format(i["last name"], i["first name"], i["location"], reason, curr_time))
                f.close()
                i["timestamp"] = datetime.datetime.strftime(datetime.date.today(), "%y\%m\%d")

        # procedures if cac not found
        if cac_out not in cacs:

            # add new person
            add_people.unknown_cac(cac_out)

            # read updated people.txt file
            f = open("stored_info/people.txt", "r")
            text = f.read()
            f.close()
            people_json = text.split("\n-_-\n")
            people = []

            # add people to list
            try:
                for i in people_json:
                    people.append(json.loads(i))
            except Exception as e:
                print()
            cacs.append(cac_out)

            # instruct user to sign out again
            print('Account created.\n')

            # loop through all people
            for i in people:

                # if person found based on cac
                if i["CAC"] == cac_out:

                    # request location info and update accordingly
                    reason = input("What kind of sign out is this? (Details\nAppointment\nOut Processing\nOther)\n")
                    reason = reason.lower()
                    i["location"] = input("Where are you going?\n")
                    i["location"] = i["location"].lower()
                    i["in_mdr"] = False

                    #update timestamp
                    curr_time = datetime.datetime.now()
                    f = open("stored_info/logs.txt", "a")
                    f.write("{}, {} left the Hangar to go to {} for {} at {}.\n".format(i["last name"], i["first name"], i["location"], reason, curr_time))
                    f.close()
                    i["timestamp"] = datetime.datetime.strftime(datetime.date.today(), "%y\%m\%d")

    # admin commands
    elif action == "admin":

        # instructions/get input
        admin_action = input("List of commands: \n\nSee logs --> logs\n\nSee status/location of all individuals --> status\n\nSee list of people registered --> people\n\nRegister more people --> add\n\n")
        
        # display logs
        if admin_action == "logs":
            f = open("stored_info/logs.txt")
            output = f.read()
            f.close()
            print("\n\n" + output + "\n\n")

        # display status of all people
        elif admin_action == "status":
            f = open("stored_info/people_status.txt")
            output = f.read()
            f.close()
            print("\n\n" + output + "\n\n")

        # display people dicts
        elif admin_action == "people":
            for i in people:
                print(json.dumps(i, indent=4))

        # add new people
        elif admin_action == "add":
            add_people.run()

            # read updated people.txt file
            f = open("stored_info/people.txt", "r")
            text = f.read()
            f.close()
            people_json = text.split("\n-_-\n")
            people = []

            # convert people javascript objects to dicts
            try:
                for i in people_json:
                    people.append(json.loads(i))
            except Exception as e:
                print()
            
            # append cac of added person to cac list
            for i in people:
                if i["CAC"] not in cacs:
                    cacs.append(i["CAC"])
            

    # update all status of all users
    updateStatus()
    