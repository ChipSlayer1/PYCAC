# import dependencies
import datetime
import json

# function to remove old inactive users
def remove_outdated():

    # read all people to variable
    f = open("stored_info/people.txt", "r")
    unprocessed_ppl = f.read()
    f.close()

    # split variable into list of all unprocessed people
    unprocessed_ppl = unprocessed_ppl.split("\n-_-\n")

    # people in dict format
    folks = []

    # people to remove
    remove = []

    # load all json ppl to dict ppl
    try:
        for i in unprocessed_ppl:
            folks.append(json.loads(i))
    except Exception as e:
        print()

    # check timestamps and filter people with old timestamps
    for i in folks:
        d1 = i["timestamp"]
        d1 = datetime.datetime.strptime(d1, "%Y\%m\%d")
        d2 = datetime.datetime.today()
        delta = d2-d1
        if delta.days >= 14:
            remove.append(i)

    # remove old timestamps from people list
    for i in range(len(folks)):
        if folks[i] in remove:
            del folks[i]

    # rewrite people file without old innactive people
    f = open("stored_info/people.txt", "w")
    f.write("")
    f.close()
    for i in folks:
        f = open("stored_info/people.txt", "a")
        f.write(json.dumps(i) + "\n-_-\n")
        f.close()
