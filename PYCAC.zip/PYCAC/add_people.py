# import dependencies
import json
import datetime

# add people the admin way
def run():

    # get number of new people to add
    number_of_ppl = int(input("How many new people will you be adding?\n"))

    # loop through number
    i = 0
    while i < number_of_ppl:

        # form to fill out
        lastName = input("Last name:\n")
        firstName = input("First name:\n")
        squadron = input("Squadron:\n")
        CAC = input("Scan Cac\n")

        # create dict based on said form
        dict = {
            'first name' : firstName,
            'last name' : lastName,
            'squadron' : squadron,
            'CAC' : CAC,
            'in_mdr' : True,
            'location' : 'mdr',
            'timestamp' : datetime.datetime.strftime(datetime.date.today(), "%Y\%m\%d")
        }
    
        # convert dict to javascript object
        person = json.dumps(dict, indent=4)

        # write javascript object to people file
        f = open("stored_info/people.txt", "a")
        f.write(person + "\n-_-\n")
        f.close()

        # increase iterable
        i+=1

# create new user if unrecognized cac entered
def unknown_cac(cac):

    # inform user of state of unrecognition
    print("\n\n** YOUR CAC HAS NOT YET BEEN REGISTERED. FILL OUT FORM BELOW **")

    # form to fill out
    lastName = input("Last name:\n")
    firstName = input("First name:\n")
    squadron = input("Squadron:\n")

    # create dict from form
    dict = {
        'first name' : firstName,
        'first name' : firstName,
            'last name' : lastName,
            'squadron' : squadron,
            'CAC' : cac,
            'in_mdr' : True,
            'location' : 'mdr',
            'timestamp' : datetime.datetime.strftime(datetime.date.today(), "%Y\%m\%d")
    }

    # convert dict to javascript object
    person = json.dumps(dict, indent=4)

    # append javascript object to people file
    f = open("stored_info/people.txt", "a")
    f.write(person + "\n-_-\n")
    f.close()